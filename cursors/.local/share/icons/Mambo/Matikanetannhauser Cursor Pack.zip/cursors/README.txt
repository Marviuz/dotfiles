===================================================================================

Head to this link for the most up to date README! Thank you for downloading this pack!

https://docs.google.com/document/d/11rdtfeZvk2nMGo2bChsvQeaRbc7f7rKb5sqk6Hr2Lo0/edit?usp=sharing



===================================================================================
Thank you for downloading this Umamusume cursor pack!!

- all pixel art by pixloen (https://x.com/pixloen)
find more cursors at: https://ko-fi.com/pixloen/shop

Want to see more Umamusume cursors? Vote for your favorites in this poll!
-----------------------------------------------------------------------------------
https://forms.gle/ozd1CpVuZy5PTmUM9


How to Install (Windows)
-----------------------------------------------------------------------------------
- Open Settings
- Search for "Mouse settings" and click on it
- On the bottom of the menu, click "Additional Mouse Settings"
- On the Mouse Properties window that pops up, click the "Pointers" tab on the top of the window.
- In the Customize area, click each cursor and Browse..., then after opening the cursor's "Windows" folder, select the Berno Light cursor with the matching name.
- Leave the Mouse Properties window open, and repeat this for each cursor. You do not need to click "OK" after selecting every cursor.
- Save the mouse scheme by clicking the "Save As" button, and click Apply on the bottom.


Note: The menu in Windows 11 "Accessibility > Mouse pointer and touch" is not recommended as the cursor may reset on Windows restart. Saving the mouse scheme prevents this issue.

Optional Things:
If the Text Select cursor is too large, you can instead use "Text Select 2", which is more standard.

How to Install  (Linux)
-----------------------------------------------------------------------------------
You can read instructions on how to install this cursor set below:
https://wiki.archlinux.org/title/Cursor_themes


How to Install (Mac)
-----------------------------------------------------------------------------------
You can find .png versions of the Windows cursors in the Mac subfolder.
Import these using Mousecape.

https://github.com/alexzielenski/Mousecape


Troubleshooting (Windows)
If the cursor is translucent or buggy, turn on Pointer Shadow.
If the cursor reverts to the default Windows cursor when restarting, 
Put these cursors in C:\Windows\Cursors.
Save the cursors as a Cursor Scheme when applying.

